import pygame, time # Impordib pygame
pygame.init() # Käivitab pygame

lBlue = [51, 204, 255] # Teeb sinise värvi

# ekraani seaded
screenX = 640 # Ekraani horisontaal suurus on 640
screenY = 480 # Ekraani vertikaal suurus on 480
screen = pygame.display.set_mode([screenX, screenY]) # Teeb ekraani
pygame.display.set_caption("Ping pong - Rovan") # Paneb ekraanile nime
screen.fill(lBlue) # Täidab tausta sinisega

Score = 0 # Paneb scorile väärtuse 0

clock = pygame.time.Clock() # Mängu refresimis kiirus
posX, posY = 0, 0 # Teeb x ja y asukoha
posX2, posY2 = 245, 300 # Teeb teise x ja y asukoha
speedX, speedY = 3, 4 # Teeb palli kiiruse
speedX2 = 2 # Teeb aluse kiiruse

pygame.mixer.music.load('peppaonlahe.mp3') # Toob muusika sisse
pygame.mixer.music.play(0) # Paneb muusika tööle

# Ball
pall = pygame.Rect(posX, posY, 20, 20) # Palli asukoht ja suurus
pallpilt = pygame.image.load("ball.png") # Toob palli pildi sisse
pallpilt = pygame.transform.scale(pallpilt, [pall.width, pall.height]) # Muudab palli suurust

# Alus
alus = pygame.Rect(posX2, posY2, 120, 20) # Teeb aluse asukoha ja suuruse
aluspilt = pygame.image.load("pad.png") # Toob aluse sisse
aluspilt = pygame.transform.scale(aluspilt, [alus.width, alus.height]) # Muudab aluse suurust

gameover = False
while not gameover:
    clock.tick(60)
    # mängu sulgemine ristist
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        break

    # Pall
    pall = pygame.Rect(posX, posY, 20, 20) # Seab palli asukohta ja suuruse
    screen.blit(pallpilt, pall) # Toob palli välja

    posX += speedX # Muudab kiirust x
    posY += speedY # Muudab kiirust y

    if posX > screenX - pallpilt.get_rect().width or posX < 0: # Kui üks tingimustest on täidetud siis...
        speedX = -speedX # ... palli speedx väärtus läheb negatiivseks

    if posY > screenY - pallpilt.get_rect().height or posY < 0: # Kui üks tingimustest on täidetud siis...
        speedY = -speedY # ... palli speedy väärtus läheb negatiivseks

    if pall.colliderect(alus) and speedY > 0: # Kui pall läheb aluse pihta ja speedY on suurem kui 0 siis...
        speedY = -speedY # ... speedY läheb negatiivseks
        Score += 1 # Lisab skoorile ühe

    if posY > 460: # Kui pall madamale kui 460 siis...
        screen.blit(pygame.font.Font(None, 100).render("GAME OVER", True, [255, 255, 255]), [110, 70]) # Toob game over teksti välja
        pygame.display.flip() # Värskendab ekraani
        time.sleep(5) # Paneb mängu 5 sekundiks pausile
        Score = 0 # ... skoor läheb alla ühe skoori võrra

    screen.blit(pygame.font.Font(None, 30).render("Score: " + str(Score), True, [0, 0, 0]), [15, 10]) # Toob skoori välja

    # Alus
    alus = pygame.Rect(posX2, posY2, 120, 20) # Seab palli asukohta ja suuruse
    screen.blit(aluspilt, alus) # Toob aluse välja

    keys = pygame.key.get_pressed() # Seab muutujale keys nuppu vajutamis funktsiooni

    if posX2 > 0: # Kui posX2 on väiksem kui 0 siis...
        if keys[pygame.K_d]: # ... saab vajutada d et liikuda
            posX2 += 3 # liigutab alust
        if keys[pygame.K_a]: # ... saab vajutada a et liiuda
            posX2 += -3 # liigutab alust
        if posX2 == -1: # Kui alus jõuab vasaku seina juurde ei saa enam liikuda
            posX2 += 3 # Lisab asukohale 3 juurde
        if posX2 > 520: # Kui alus jõuab parema seina juurde ei saa enam liikuda
            posX2 -= 3 # Lisab asukohale -3 juurde

    if posX2 > screenX - aluspilt.get_rect().width or posX2 < 0: # Kui üks tingimus on täidetud siis...
        speedX2 = -speedX2 # ... speedx2 muutub negatiivseks

    pygame.display.flip() # Värskendab ekraani
    screen.fill(lBlue) # Täidab tausta sinisega



pygame.quit()
