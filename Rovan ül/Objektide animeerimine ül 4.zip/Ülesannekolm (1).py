import pygame, sys, random, time # Toob sisse kolm moodulit

pygame.init() # Käivitab pygame'i

# Ekraani seaded
screenX = 640 # Seab ekraani horistontaalse laiuse väärtuse
screenY = 480 # Seab ekraani vertikaalse laiuse väärtuse
screen=pygame.display.set_mode([screenX,screenY]) # Seab ekraani horisontaalse ja vertikaalse laiuse 640x480
pygame.display.set_caption("Animeerimine - Rovan") # Seab ekraani nimeks Animeerimine - Rovan
clock = pygame.time.Clock() # Seab clock väärtuseks pygame mooduli osa time.clock

# Taust
bg = pygame.image.load("bg_rally.png") # Toob sisse taustapildi ehk raja
#screen.blit(bg, [0, 0]) # Toob pildi välja ja määrab asukoha

# Punane auto
punaneauto = pygame.image.load("f1_red.png") # Toob punase auto pildi sisse
screen.blit(punaneauto, [298, 360]) # Toob punase auto pildi välja ja määrab asukoha
car3X = 298 # Auto asukoht X
car3Y = 360 # Auto asukoht Y

PosBGY1= 0 # Tausta 1 asukoht Y
PosBGY2= 480 # Tausta 2 asukoht Y

# Sinine auto
sinineauto = pygame.image.load("f1_blue(1).png") # Toob sinise auto pildi sisse
screen.blit(sinineauto, [200, 200]) # Toob sinise auto pildi välja ja määrab asukoha

# Esimene sinine auto
car1X = random.randint(155, 280) # Esimene auto horisontaalne asukoht on suvakas number 155 ja 280 vahel
car1Y = 0 # Määrab vertikaalseks asukohaks 0

# Teine sinine auto
car2X = random.randint(361, 454) # Teise auto horisontaalne asukoht on suvakas number 361 ja 454 vahel
car2Y = 0 # Määrab vertikaalseks asukohaks 0

# Skoor
skoor = 0 # Seab skoori väärtuseks 0
def Manguskoor(number): # Teeb funktsiooni Manguskoor
    inc = "Jah" # Küsib kasutajalt sisendust
    if inc == "Jah" or "jah": # Kui vastus on jah siis mäng hakkab
        return number

gameover1 = pygame.image.load("gameover1.png") # Toob sisse gameover pildi
gameover2 = pygame.transform.scale(gameover1, (250, 125)) # Muudab gameover pildi suurust


skoor = Manguskoor(skoor) # Teeb objekti skoor

gameover = False
while not gameover:
    #fps
    clock.tick(60)
    ev = pygame.event.get()

    for event in ev:
        if event.type == pygame.MOUSEBUTTONUP:
            x, y = pygame.mouse.get_pos()
            print(x, y)

    # Mängu sulgemine ristist
    events = pygame.event.get()
    for i in pygame.event.get():
       if i.type == pygame.QUIT:
           sys.exit()

    keys = pygame.key.get_pressed() # Kui kutsun keys siis saan nuppe panna asju tegema
    if keys[pygame.K_q]: # Et q mängu kinni paneks
        break # Paneb mängu kinni

    # Punane auto

    if event.type == pygame.KEYDOWN: # Kui mingit nuppu vajutatakse
        if event.key == pygame.K_RIGHT: # Et parem nool liigutaks autot
            car3X += 3 # Liigutab auto paremale
        if event.key == pygame.K_LEFT: # Et vasak nool liigutaks autot
            car3X += -3 # Liigutab auto vasakule
    if keys[pygame.K_d]: # Et d auto paremale liigutaks
        car3X +=3 # Liigutab auto paremale
    if keys[pygame.K_a]: # ET a auto vasakule liigutaks
        car3X +=-3 # Liigutab auto vasakule
    screen.blit(punaneauto, (car3X, car3Y)) # Toob punase auto välja
    if car3X > 455: # Kui auto läheb vastu paremat tee äärt siis saab mäng läbi
        screen.blit(gameover2, [195, 80]) # Toob välja game over pildi
        lahkumine = font.render("Lahkumiseks vajuta Q ", True, [0, 0, 0])  # Teeb teksti ja seadistab selle
        screen.blit(lahkumine, [210, 350]) # Toob välja teksti kuidas lahkuda
        if keys[pygame.K_q]: # Kui vajutad Q
            break # Siis mäng läheb kinni
        time.sleep(1) # Paneb mängu korras magama ja aeglustab

    # Skoor
    font = pygame.font.Font(None, 30) # Teeb fondi
    skoorvalja = font.render("Skoor: " + str(skoor), True, [0, 0, 0]) # Teeb teksti ja seadistab selle

    # Sinised autod
    screen.blit(sinineauto, (car1X, car1Y)) # Toob esimese auto välja ja määrab esimese auto asukoha
    screen.blit(sinineauto, (car2X, car2Y)) # Toob teise auto välja ja määrab teise auto asukoha

    car1Y += 3 # Esimese auto kiirus
    car2Y += 3 # Teise auto kiirus

    if car1Y > 510: # Kui esimese auto vertikaalne asukoht on suurem kui 510 siis...
        car1Y = -100 # ... auto läheb vertikaal asukohale -100
        car1X = random.randint(155, 280) # ... auto saab uue suvaka horisontaalse asukoha 155 ja 280 vahel
        skoor += 1 # Lisab skoorile ühe kui esimene auto jõuab alla

    if car2Y > 510: # Kui teise auto vertikaalne asukoht on suurem kui 510 siis...
        car2Y = -150 # ... auto läheb vertikaal asukohale -100
        car2X = random.randint(361, 454) # ... auto saab uue suvaka horisontaalse asukoha 361 ja 454 vahel
        skoor += 1 # Lisab skoorile ühe kui teine auto jõuab alla

    # Graafika kuvamine ekraanil
    pygame.display.flip() # Värskendab ekraani
    a = 1 # Paneb a väärtuse 1
    if a < 2: # Kui a on väiksem kui 2
        PosBGY1 -= 3 # Liidab BG 1 backgroundile 3 juurde, et taust liiguks
        if PosBGY1 == -480: # Kui BG 1 on asukohal 480
            PosBGY1 += 480 # Siis lahutab BG 1 asukohast 480
        PosBGY2 -= 3 # Liidab BG 2 backgroundile 3 juurde, et taust liiguks
        if PosBGY2 == 0: # Kui BG 2 on asukohal 0
            PosBGY2 += +480 # Siis lahuta BG 2 asukohast 480
    screen.blit(bg, [0, PosBGY1]) # Toob tausta 1 uuesti välja
    screen.blit(bg, [0, PosBGY2]) # Toob tausta 2 uuesti väljad
    screen.blit(skoorvalja, [280, 45]) # Toob skoori välja

    if car3X < 140: # Kui auto läheb vastu vasakut tee äärt siis saab mäng läbi
        screen.blit(gameover2, [195, 80]) # Toob välja game over pildi
        lahkumine = font.render("Lahkumiseks vajuta Q ", True, [0, 0, 0])  # Teeb teksti ja seadistab selle
        screen.blit(lahkumine, [210, 350]) # Toob välja teksti kuidas lahkuda
        if keys[pygame.K_q]: # Kui vajutad Q
            break # Siis mäng läheb kinni
        time.sleep(1) # Paneb mängu korras magama ja aeglustab



